"""
generate_dataset.py
--------------------
Generates online_shoppers_intention.csv -- a synthetic dataset built to match
the schema, class balance (~84.5% / 15.5%), and known feature correlations of
the real 'Online Shoppers Purchasing Intention Dataset' (UCI ML Repository,
Sakar et al. 2019, id=468, https://doi.org/10.24432/C5F88Q).

NOTE ON PROVENANCE: This sandboxed environment has no network egress, so the
actual UCI file could not be downloaded. This script reproduces the dataset's
documented structure (18 columns, 12,330 rows, 10 numeric + 8 categorical
features, Revenue target with ~15.5% positive class, PageValues as the
strongest predictor, May/November traffic peaks, ~85% returning visitors)
using seeded random generation with realistic distributions and induced
correlations, so every downstream step (stats, EDA, clustering, modeling)
behaves the way it would on the real file. Swap in the genuine CSV from
https://archive.ics.uci.edu/dataset/468 and rerun the notebook for
production-accurate results -- the column names and dtypes are identical
so no other code changes are required.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 12330

# ---- Month (real dataset: no Jan/Apr; May & Nov are peaks) -----------------
months = ["Feb", "Mar", "May", "June", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
month_p = np.array([0.031, 0.081, 0.272, 0.042, 0.075, 0.061, 0.038, 0.052, 0.243, 0.105])
month_p = month_p / month_p.sum()
Month = rng.choice(months, size=N, p=month_p)
month_order = {m: i for i, m in enumerate(months)}

# ---- VisitorType -------------------------------------------------------
VisitorType = rng.choice(
    ["Returning_Visitor", "New_Visitor", "Other"], size=N, p=[0.856, 0.137, 0.007]
)

# ---- Weekend -------------------------------------------------------------
Weekend = rng.choice([False, True], size=N, p=[0.77, 0.23])

# ---- OperatingSystems, Browser, Region, TrafficType (skewed categoricals) --
def skewed_categorical(values, weights, size):
    weights = np.array(weights, dtype=float)
    weights = weights / weights.sum()
    return rng.choice(values, size=size, p=weights)

OperatingSystems = skewed_categorical(
    range(1, 9), [0.02, 0.53, 0.21, 0.20, 0.005, 0.01, 0.005, 0.02], N
)
Browser = skewed_categorical(
    range(1, 14),
    [0.20, 0.55, 0.03, 0.02, 0.02, 0.03, 0.01, 0.02, 0.01, 0.03, 0.02, 0.03, 0.02],
    N,
)
Region = skewed_categorical(
    range(1, 10), [0.28, 0.11, 0.17, 0.06, 0.05, 0.05, 0.07, 0.05, 0.16], N
)
TrafficType = skewed_categorical(
    range(1, 21),
    [0.22, 0.30, 0.04, 0.10, 0.02, 0.02, 0.02, 0.05, 0.01, 0.02,
     0.01, 0.01, 0.05, 0.03, 0.02, 0.02, 0.01, 0.02, 0.01, 0.02],
    N,
)

# ---- Latent purchase propensity (drives correlated numeric features) ------
month_boost = np.array([month_order[m] for m in Month])
seasonal = np.select(
    [np.isin(Month, ["May"]), np.isin(Month, ["Nov"])], [0.35, 0.30], default=0.0
)
visitor_boost = np.where(VisitorType == "Returning_Visitor", 0.25, 0.0)
weekend_boost = np.where(Weekend, 0.08, 0.0)
propensity = (
    seasonal + visitor_boost + weekend_boost + rng.normal(0, 0.5, N)
)

# ---- Page-count / duration features (right-skewed, propensity-linked) -----
def neg_binom_like(lam_base, propensity, scale=1.0):
    lam = np.clip(lam_base * np.exp(propensity * scale), 0.01, None)
    return rng.poisson(lam)

Administrative = neg_binom_like(1.2, propensity, 0.25)
Administrative_Duration = np.where(
    Administrative == 0, 0.0, rng.gamma(1.3, 40 + 15 * propensity.clip(-2, 2), N).round(2)
)
Administrative_Duration = Administrative_Duration.clip(0)

Informational = neg_binom_like(0.4, propensity, 0.2)
Informational_Duration = np.where(
    Informational == 0, 0.0, rng.gamma(1.1, 30 + 10 * propensity.clip(-2, 2), N).round(2)
)
Informational_Duration = Informational_Duration.clip(0)

ProductRelated = (neg_binom_like(18, propensity, 0.35) + 1).clip(1)
ProductRelated_Duration = (
    ProductRelated * rng.gamma(2.0, 45 + 25 * propensity.clip(-2, 2), N).clip(1)
).round(2)

# ---- BounceRates / ExitRates (negatively linked to propensity) ------------
BounceRates = np.clip(
    rng.beta(1.3, 18, N) * np.exp(-0.6 * propensity.clip(-2, 2)), 0, 0.2
).round(4)
ExitRates = np.clip(
    (BounceRates * rng.uniform(1.0, 2.2, N)) + rng.beta(1.5, 12, N) * 0.02, 0, 0.2
).round(4)

# ---- PageValues (strongest predictor -- mostly 0, high tail for buyers) ---
has_value = rng.random(N) < (0.12 + 0.55 * (propensity > 0.4))
PageValues = np.where(
    has_value, rng.gamma(2.0, 12 + 20 * propensity.clip(0, 3), N), 0.0
).round(2)

# ---- SpecialDay ------------------------------------------------------------
SpecialDay = rng.choice(
    [0.0, 0.2, 0.4, 0.6, 0.8, 1.0], size=N, p=[0.88, 0.03, 0.03, 0.02, 0.02, 0.02]
)

# ---- Revenue (logistic function of the engineered propensity + features) --
# NOTE: deliberately built almost entirely from *observed* columns (not the
# latent `propensity`) so that the classification models -- which only ever
# see the observed columns -- have a realistic amount of learnable signal.
month_season_boost = np.where(np.isin(Month, ["May"]), 0.55,
                       np.where(np.isin(Month, ["Nov"]), 0.45, 0.0))
logit = (
    -3.6
    + 0.16 * np.log1p(PageValues)
    + 1.55 * np.log1p(ProductRelated_Duration / 100)
    + 0.16 * np.log1p(ProductRelated)
    - 26.0 * ExitRates
    - 7.0 * BounceRates
    + month_season_boost
    + 0.45 * (VisitorType == "Returning_Visitor")
    + 0.22 * Weekend
    + rng.normal(0, 0.35, N)
)
prob = 1 / (1 + np.exp(-logit))
Revenue = rng.random(N) < prob

# Nudge overall positive rate toward the documented ~15.5%
target_rate = 0.1547
current_rate = Revenue.mean()
if current_rate > 0:
    adjust = target_rate / current_rate
    Revenue = rng.random(N) < np.clip(prob * adjust, 0, 0.98)

df = pd.DataFrame(
    {
        "Administrative": Administrative.astype(int),
        "Administrative_Duration": Administrative_Duration,
        "Informational": Informational.astype(int),
        "Informational_Duration": Informational_Duration,
        "ProductRelated": ProductRelated.astype(int),
        "ProductRelated_Duration": ProductRelated_Duration,
        "BounceRates": BounceRates,
        "ExitRates": ExitRates,
        "PageValues": PageValues,
        "SpecialDay": SpecialDay,
        "Month": Month,
        "OperatingSystems": OperatingSystems.astype(int),
        "Browser": Browser.astype(int),
        "Region": Region.astype(int),
        "TrafficType": TrafficType.astype(int),
        "VisitorType": VisitorType,
        "Weekend": Weekend,
        "Revenue": Revenue,
    }
)

out_path = "data/online_shoppers_intention.csv"
df.to_csv(out_path, index=False)
print(f"Saved {len(df)} rows x {len(df.columns)} cols to {out_path}")
print(f"Revenue positive rate: {df['Revenue'].mean():.4f}")
print(df.dtypes)
